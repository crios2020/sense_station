package ar.org.centro35.Sensores;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SensoresApplicationTests {

	@Test
	void contextLoads() {
	}

}
